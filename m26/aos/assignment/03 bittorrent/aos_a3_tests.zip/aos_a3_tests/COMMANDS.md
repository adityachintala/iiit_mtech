# Student Test Commands

Run the scenarios in order after completing `README.md`. A, B, and C denote the client terminals. T1 and T2 denote tracker terminals. Commands inside client blocks are entered in the running client.

## Scenario 1: User accounts and sessions

### 1.1 Terminal A

```text
create_user a3_alice AliceA3pass
create_user a3_alice AnotherPass
login a3_alice WrongPass
login a3_alice AliceA3pass
```

### 1.2 Terminal B

```text
create_user a3_bob BobA3pass
login a3_bob BobA3pass
```

### 1.3 Terminal C

```text
create_user a3_carol CarolA3pass
login a3_carol CarolA3pass
logout
create_group a3_logged_out
login a3_carol CarolA3pass
```

## Scenario 2: Group management

### 2.1 Terminal A

```text
create_group a3_main
```

### 2.2 Terminal B

```text
list_groups
create_group a3_main
join_group a3_main
```

### 2.3 Terminal A

```text
list_requests a3_main
```

### 2.4 Terminal C

```text
list_requests a3_main
accept_request a3_main a3_bob
```

### 2.5 Terminal A

```text
accept_request a3_main a3_bob
list_requests a3_main
```

### 2.6 Terminal B

```text
leave_group a3_main
join_group a3_main
```

### 2.7 Terminal A

```text
accept_request a3_main a3_bob
```

## Scenario 3: File registration, access, and withdrawal

### 3.1 Terminal A

```text
upload_file a3_main fixtures/exact_512k.bin
```

### 3.2 Terminal B

```text
list_files a3_main
```

### 3.3 Terminal C

```text
list_files a3_main
download_file a3_main exact_512k.bin downloads/carol/nonmember.bin
```

### 3.4 Terminal A

```text
stop_share a3_main exact_512k.bin
```

### 3.5 Terminal B

```text
list_files a3_main
download_file a3_main exact_512k.bin downloads/bob/withdrawn.bin
```

### 3.6 Terminal A

```text
upload_file a3_main fixtures/exact_512k.bin
upload_file a3_main fixtures/tail_512k_plus_1.bin
upload_file a3_main fixtures/movie.mkv
```

### 3.7 Terminal B

```text
upload_file a3_main fixtures/movie.mkv
list_files a3_main
```

### 3.8 Terminal C

```text
join_group a3_main
```

### 3.9 Terminal A

```text
list_requests a3_main
accept_request a3_main a3_carol
```

## Scenario 4: Boundary files and movie download

### 4.1 Terminal C

Complete each boundary-file download before entering the next command:

```text
download_file a3_main exact_512k.bin downloads/carol/exact_512k.bin
download_file a3_main tail_512k_plus_1.bin downloads/carol/tail_512k_plus_1.bin
show_downloads
```

### 4.2 Terminal C

Start the movie download:

```text
download_file a3_main movie.mkv downloads/carol/movie.mkv
```

While that transfer is running, enter these commands without waiting for the movie to finish:

```text
download_file a3_main tail_512k_plus_1.bin downloads/carol/tail_parallel.bin
show_downloads
```

Keep both A and B running as movie seeders. Retain any available piece-transfer or connection logs.

### 4.3 Optional peer-interruption variation

Perform this variation only if requested by your TA. During the movie transfer, press `Ctrl+C` in terminal B. Leave A and C running. Terminal B is not needed for the remaining scenarios.

If repeating a movie download for this variation, use `downloads/carol/movie_retry.mkv` as the destination and adjust the comparison command accordingly.

### 4.4 Terminal C

After the transfers finish:

```text
show_downloads
```

### 4.5 Separate operating-system shell

Run these comparisons from the extracted test directory after the corresponding downloads have finished:

```sh
cd "$HOME/aos_a3_tests"
cmp fixtures/exact_512k.bin downloads/carol/exact_512k.bin
cmp fixtures/tail_512k_plus_1.bin downloads/carol/tail_512k_plus_1.bin
cmp fixtures/tail_512k_plus_1.bin downloads/carol/tail_parallel.bin
cmp fixtures/movie.mkv downloads/carol/movie.mkv
```

## Scenario 5: Tracker outage, recovery, and failover

Complete Scenario 4 before beginning this scenario. A and C initially use T1. Do not stop T1 yet.

### 5.1 Terminal T2: process event

Stop Tracker 2 with `Ctrl+C`. Leave Tracker 1 and clients A and C running.

### 5.2 Terminal A

```text
create_group a3_recovery
```

### 5.3 Terminal C

```text
join_group a3_recovery
```

### 5.4 Terminal A

```text
list_requests a3_recovery
accept_request a3_recovery a3_carol
upload_file a3_recovery fixtures/tail_512k_plus_1.bin
stop_share a3_main exact_512k.bin
```

### 5.5 Terminal C

```text
download_file a3_recovery tail_512k_plus_1.bin downloads/carol/recovery_tail.bin
stop_share a3_main exact_512k.bin
```

### 5.6 Terminal T2: restart

In the operating-system shell:

```sh
cd "$HOME/aos_a3_tests"
./bin/tracker tracker_info.txt 2
```

Allow 15 seconds for recovery before continuing.

### 5.7 Terminal C: switch tracker

In Carol's running client:

```text
logout
```

Allow the command to finish, then stop only Carol's client with `Ctrl+C`. Restart Carol against T2 using the applicable instructions in `README.md`. Do not restart A or T1.

### 5.8 Terminal C: commands through T2

```text
login a3_carol CarolA3pass
list_groups
list_files a3_main
list_files a3_recovery
upload_file a3_recovery fixtures/tail_512k_plus_1.bin
```

Allow a short synchronization interval before the next event. Keep Carol's client running through T2 as a seeder.

### 5.9 Terminal T1: process event

Stop Tracker 1 with `Ctrl+C`. Keep Tracker 2 and Carol's client running. Leave Alice's existing client process in place.

### 5.10 Terminal A

Enter these in Alice's existing client if it remains running:

```text
list_groups
list_files a3_recovery
download_file a3_recovery tail_512k_plus_1.bin downloads/alice/recovery_tail.bin
show_downloads
```

If the client requests authentication as part of recovery, use `login a3_alice AliceA3pass`, then repeat the interrupted command. Record whether any manual process restart was needed; do not restart Alice silently. Continue Scenario 6 in Carol's client even if Alice's process cannot continue.

## Scenario 6: Invalid inputs and shutdown

### 6.1 Terminal C

```text
upload_file a3_recovery fixtures/not_present.bin
download_file a3_recovery not_shared.bin downloads/carol/not_shared.bin
download_file a3_recovery tail_512k_plus_1.bin downloads/not_created/tail.bin
invalid_command
show_downloads
leave_group a3_main
logout
list_groups
```

Do not create `downloads/not_created` before this scenario.

### 6.2 Terminal T2

Enter this in the tracker's console:

```text
quit
```

Use `Ctrl+C` in each remaining test process's terminal to end the session if needed. Retain downloaded files and logs for your demonstration.
